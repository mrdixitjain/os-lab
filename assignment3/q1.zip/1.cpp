#include <bits/stdc++.h> 
using namespace std; 
int main (int argc, char** argv) 
{ 
    
   
	 string str = "gcc "; 
    str = str + " -o aa " + argv[1]; 
  
    // Convert string to const char * as system requires 
    // parameter of type const char * 
    const char *command = str.c_str(); 
  
    cout << "Compiling file using " << command << endl; 
    system(command);  
    string s="aa ";
     str = "readelf "; 
    str = str  + s + "-h " + ">> output.txt"; 
  
    
    const char *comman = str.c_str(); 
  
    cout  << comman << endl; 
    system(comman); 

    cout << "\nRunning file "; 
  
    return 0; 
} 
